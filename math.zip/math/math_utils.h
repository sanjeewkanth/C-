#ifndef MATH_UTILS
#define MATH_UTILS

struct Rectangle
{
	double length;
	double width;
};
double pow(double base, int pow);
double area(Rectangle rectangle);
double area(double length);
double area(double length, double width);
#endif
