#include <iostream>
#include "math_utils.h"

int main()
{
	std::cout<<pow(3,3)<<std::endl;
	//std::cout<<pow(3)<<std::endl;
	//return 0;
}
